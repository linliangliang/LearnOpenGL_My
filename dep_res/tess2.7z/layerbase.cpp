#include "glmap/layerbase.h"
#include "vt.hpp"

#include "tileutility/tilerule.h"
#include "tileutility/tilelevel.h"
#include "tileutility/tilesinfo.h"
#include "tileutility/tileorigin.h"
#include "tileutility/tilepixelsize.h"
#include "tileutility/tilelevelinfo.h"
#include "tileutility/tilereference.h"
#include "tileutility/tilereferencefactory.h"

#include "tesselator.h"

#include <algorithm>

using namespace evm::glbase;

namespace evm
{
	namespace glmap
	{
		LayerBase::LayerBase(const std::string& name)
			:mName(name)
		{
		}


		EarthView::World::Spatial::CTileReference* LayerBase::getTileReference()
		{
			using namespace EarthView::World::Spatial;
			static CTileReference* pTileReference = nullptr;
			if (nullptr == pTileReference)
			{
				CTileOrigin tileOrigin;
				tileOrigin.setHeight(360.0);
				tileOrigin.setWidth(360.0);
				tileOrigin.setX(-180.0);
				tileOrigin.setY(180);
				tileOrigin.setOriginPosition(OPT_LEFTTOP);

				CTileLevel tileLevel;
				tileLevel.setBaseLevel(0);
				tileLevel.setHasMaxLevel(true);
				tileLevel.setHasMinLevel(true);
				tileLevel.setMaxLevel(18);
				tileLevel.setMinLevel(0);
				tileLevel.setSpanOfBaseLevel(360.0);

				CTilePixelSize pixelSize;
				pixelSize.setHeight(256);
				pixelSize.setWidth(256);

				CTileRule tileRule;
				tileRule.setTileLevel(tileLevel);
				tileRule.setTileOrigin(tileOrigin);
				tileRule.setTilePixelSize(pixelSize);
				tileRule.setTileUnits(TUT_DEGREE);

				pTileReference = new CTileReference(tileRule);
			}
			return pTileReference;
		}

		void LayerBase::getEVTiles(const DisplayInfo& displayinfo, DISPLAY_INFO& info)
		{
			using namespace EarthView::World::Spatial;
			CTileReference* pTileReference = getTileReference();

			////��ȡ��ǰ����
			info.level = pTileReference->getTileRuleRef()->getTileLevelRef()->getMinLevel();
			float currentScale = displayinfo.mCurrentScale;////��ǰcurrentScale��EV�Ⱥ������1000
			CTileLevelInfo* pBaseLevelInfo = pTileReference->getLevelInfo(info.level);
			double scale = 1.0 / pBaseLevelInfo->getScale();

			delete pBaseLevelInfo;
			while (currentScale < scale && info.level < pTileReference->getTileRuleRef()->getTileLevelRef()->getMaxLevel())
			{
				scale *= 0.5;
				++info.level;
			}
			--info.level;
			if (info.level < pTileReference->getTileRuleRef()->getTileLevelRef()->getMinLevel())
			{
				info.level = pTileReference->getTileRuleRef()->getTileLevelRef()->getMinLevel();
			}
			CTileLevelInfo* pLevelInfo = pTileReference->getLevelInfo(info.level);
			if (pLevelInfo)
			{
				glVec2 maxxy = displayinfo.mMax;
				glVec2 minxy = displayinfo.mMin;

				double minx = minxy.x;
				double miny = minxy.y;
				double maxx = maxxy.x;
				double maxy = maxxy.y;
				if (minx < -180.0)
				{
					minx = -180;
				}
				if (miny < -90)
				{
					miny = -90;
				}
				if (maxx > 180)
				{
					maxx = 180;
				}
				if (maxy > 90)
				{
					maxy = 90;
				}
				CTilesInfo* pTilesInfo = pLevelInfo->getTilesInfo(minx, miny, maxx, maxy);
				if (pTilesInfo)
				{
					info.minRow = pTilesInfo->getMinRow();
					info.minCol = pTilesInfo->getMinCol();
					info.maxRow = pTilesInfo->getMaxRow();
					info.maxCol = pTilesInfo->getMaxCol();
					delete pTilesInfo;
				}
				delete pLevelInfo;
			}
		}

		void LayerBase::getLevelScaleRange(int level, double& minscale, double& maxscale)
		{
			using namespace EarthView::World::Spatial;
			CTileReference* pTileReference = getTileReference();
			CTileLevelInfo* pLevelInfo = pTileReference->getLevelInfo(level);

			if (level < pTileReference->getTileRuleRef()->getTileLevelRef()->getMinLevel())
			{
				minscale = maxscale = 0;
				return;
			}
			if (level > pTileReference->getTileRuleRef()->getTileLevelRef()->getMaxLevel())
			{
				level = pTileReference->getTileRuleRef()->getTileLevelRef()->getMaxLevel();
			}

			if (level == pTileReference->getTileRuleRef()->getTileLevelRef()->getMaxLevel())
			{
				maxscale = 0;
			}
			else
			{
				CTileLevelInfo* pNextLevelInfo = pTileReference->getLevelInfo(level + 1);
				maxscale = 1.0 / pNextLevelInfo->getScale();
				delete pNextLevelInfo;
			}
			minscale = 1.0 / pLevelInfo->getScale();
			delete pLevelInfo;
		}

		void LayerBase::getEVTileMinMax(int level, int row, int col, glVec2& minpos, glVec2& maxpos)
		{
			using namespace EarthView::World::Spatial;
			CTileReference* pTileReference = getTileReference();
			CTileLevelInfo* pBaseLevelInfo = pTileReference->getLevelInfo(level);
			CTileInfo* pTileInfo = pBaseLevelInfo->getTileInfoByRowCol(row, col);
			minpos.x = pTileInfo->getMinX();
			minpos.y = pTileInfo->getMinY();
			maxpos.x = pTileInfo->getMaxX();
			maxpos.y = pTileInfo->getMaxY();
			delete pTileInfo;
			delete pBaseLevelInfo;
		}

		bool LayerBase::isIntersects(const glVec2& maxpt, const glVec2& minpt)
		{
			double maxx = std::max(maxpt.x, mMax.x);
			double minx = std::min(minpt.x, mMin.x);
			double maxy = std::max(maxpt.y, mMax.y);
			double miny = std::min(minpt.y, mMin.y);
			return ((maxx - minx) <= maxpt.x - minpt.x + mMax.x - mMin.x) && ((maxy - miny) <= maxpt.y - minpt.y + mMax.y - mMin.y);
		}

		bool LayerBase::tesselator(const evm::geometry::multi_line_string<float>& lines, std::vector<evm::glbase::glVec3>& outvertex, std::vector<int>& outindices)
		{
			outvertex.clear();
			outindices.clear();
			if (lines.size() < 1)
			{
				return false;
			}

			auto tess = tessNewTess(nullptr);
			for (const auto& ring : lines)
			{
				int ringsize = ring.size();
				if (ringsize < 2)
				{
					continue;
				}
				tessAddContour(tess, 2, ring.data(), 2 * sizeof(float), ringsize);
			}
			if (tessTesselate(tess, TESS_WINDING_ODD, TESS_POLYGONS, 3, 2, nullptr))
			{
				int nv = tessGetVertexCount(tess);
				const TESSreal* src = tessGetVertices(tess);
				int nelems = tessGetElementCount(tess);
				const TESSindex* elems = tessGetElements(tess);
				for (int i = 0; i < nv; ++i)
				{
					outvertex.push_back(glVec3(src[2 * i], src[2 * i + 1], 0));
				}
				for (int i = 0; i < nelems; ++i)
				{
					const int* p = &elems[i * 3];
					for (int j = 0; j < 3 && p[j] != TESS_UNDEF; ++j)
					{
						outindices.push_back(p[j]);
					}
				}
			}
			tessDeleteTess(tess);
			return !outindices.empty();
		}

		bool LayerBase::tesselator(const evm::vt::TileRings& rings, std::vector<evm::glbase::glVec3>& outvertex, std::vector<int>& outindices)
		{
			evm::geometry::multi_line_string<float> lines;
			for (const auto& ring : rings)
			{
				evm::geometry::line_string<float> line;
				int ringsize = ring.size();
				if (ringsize < 2)
				{
					continue;
				}
				for (int i = 0; i < ringsize; ++i)
				{
					line.push_back(evm::geometry::point<float>(ring[i].x, ring[i].y));
				}
				lines.push_back(std::move(line));
			}
			return tesselator(lines, outvertex, outindices);
		}

	}
}